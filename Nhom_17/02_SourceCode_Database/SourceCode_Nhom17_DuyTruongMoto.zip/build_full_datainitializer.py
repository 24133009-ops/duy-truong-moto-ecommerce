import json
import re

with open('parsed_products.json', 'r', encoding='utf-8') as f:
    products = json.load(f)

print(f"Total products to generate: {len(products)}")

# Template header
header = """package com.duytruongmoto.ecommerce.data;

import com.duytruongmoto.ecommerce.entity.*;
import com.duytruongmoto.ecommerce.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final UserLevelRepository userLevelRepository;
    private final CommissionRepository commissionRepository;
    private final DeliveryRepository deliveryRepository;
    private final CategoryRepository categoryRepository;
    private final StoreRepository storeRepository;
    private final ProductRepository productRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        log.info(">>> Duy Truong Motor DataInitializer: Đang đồng bộ toàn bộ dữ liệu 60 sản phẩm...");

        // 1. User Levels & Users
        if (userLevelRepository.count() == 0 || userRepository.count() == 0) {
            initBaseData();
        }

        // 2. Categories
        Map<String, Category> catMap = initCategories();

        // 3. Stores
        Map<Integer, Store> storeMap = initStores();

        // 4. Products: Đảm bảo toàn bộ 60 sản phẩm luôn có mặt trong hệ thống
        initAll60Products(catMap, storeMap);

        log.info(">>> Đã đồng bộ thành công {} sản phẩm trong kho Duy Truong Motor!", productRepository.count());
    }

    private void initBaseData() {
        // User Levels
        UserLevel silver = userLevelRepository.save(UserLevel.builder().name("Thành viên Bạc").minPoint(0L).discount(BigDecimal.ZERO).isDeleted(false).build());
        UserLevel gold = userLevelRepository.save(UserLevel.builder().name("Khách hàng Vàng").minPoint(1000L).discount(BigDecimal.valueOf(3.0)).isDeleted(false).build());
        UserLevel diamond = userLevelRepository.save(UserLevel.builder().name("Khách hàng Kim Cương VIP").minPoint(5000L).discount(BigDecimal.valueOf(7.0)).isDeleted(false).build());

        // Commissions
        commissionRepository.save(Commission.builder().name("Chiết khấu Tiêu chuẩn").cost(BigDecimal.valueOf(5.0)).description("Chiết khấu 5% cho showroom đối tác").isDeleted(false).build());
        commissionRepository.save(Commission.builder().name("Chiết khấu Đại lý VIP").cost(BigDecimal.valueOf(3.0)).description("Chiết khấu ưu đãi 3%").isDeleted(false).build());

        // Deliveries
        deliveryRepository.save(Delivery.builder().name("Giao xe sàn trượt thủy lực VIP (Chống trầy xước 100%)").description("Xe chuyên dụng sàn trượt hạ đất, bàn giao tận phòng khách khách hàng").price(BigDecimal.valueOf(1500000)).isDeleted(false).build());
        deliveryRepository.save(Delivery.builder().name("Xe tải thùng kín chuyên dụng chuyển môtô").description("Xe tải thùng bạt chuyên chở xe PKL đi tỉnh").price(BigDecimal.valueOf(800000)).isDeleted(false).build());
        deliveryRepository.save(Delivery.builder().name("Giao hàng tiêu chuẩn (Phụ tùng, đồ bảo hộ)").description("Giao nhanh trong 2-3 ngày").price(BigDecimal.valueOf(50000)).isDeleted(false).build());

        // Users
        userRepository.save(User.builder()
                .firstname("Duy").lastname("Trường")
                .slug("duy-truong-admin")
                .email("admin@duytruongmoto.com").phone("0901234567")
                .password(passwordEncoder.encode("admin123"))
                .role(Role.ROLE_ADMIN).isEmailActive(true).isPhoneActive(true)
                .avatar("https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80")
                .point(9999L).eWallet(BigDecimal.valueOf(500000000)).userLevel(diamond).build());

        userRepository.save(User.builder()
                .firstname("Quản lý").lastname("Chi nhánh")
                .slug("manager-duytruong")
                .email("manager@duytruongmoto.com").phone("0902345678")
                .password(passwordEncoder.encode("manager123"))
                .role(Role.ROLE_MANAGER).isEmailActive(true).isPhoneActive(true)
                .point(500L).userLevel(gold).build());

        userRepository.save(User.builder()
                .firstname("Minh").lastname("Showroom Q1")
                .slug("minh-showroom-q1")
                .email("vendor@duytruongmoto.com").phone("0903456789")
                .password(passwordEncoder.encode("vendor123"))
                .role(Role.ROLE_VENDOR).isEmailActive(true).isPhoneActive(true)
                .point(2000L).eWallet(BigDecimal.valueOf(150000000)).userLevel(gold).build());

        userRepository.save(User.builder()
                .firstname("Tuấn").lastname("Vận Chuyển")
                .slug("tuan-shipper")
                .email("shipper@duytruongmoto.com").phone("0904567890")
                .password(passwordEncoder.encode("shipper123"))
                .role(Role.ROLE_SHIPPER).isEmailActive(true).isPhoneActive(true)
                .point(100L).userLevel(silver).build());

        userRepository.save(User.builder()
                .firstname("Hùng").lastname("Biker")
                .slug("hung-biker")
                .email("customer@duytruongmoto.com").phone("0905678901")
                .password(passwordEncoder.encode("customer123"))
                .role(Role.ROLE_USER).isEmailActive(true).isPhoneActive(true)
                .point(350L).eWallet(BigDecimal.valueOf(50000000)).userLevel(silver).build());
    }

    private Map<String, Category> initCategories() {
        Map<String, Category> catMap = new HashMap<>();
        String[][] catDefs = {
            {"Siêu Xe Ô Tô & Xe Sang", "oto", "/images/lamborghini_huracan.jpg"},
            {"Xe Nhỏ & Tay Ga Sưu Tầm", "xenho", "/images/honda_monkey_125.jpg"},
            {"Xe Cào Cào - Địa Hình", "dirtbike", "/images/ktm_300_exc.jpg"},
            {"Superbike / Thể Thao", "superbike", "/images/ducati_panigale_v4s.jpg"},
            {"Hyper Naked Đường Phố", "hyper-naked", "/images/ducati_streetfighter.jpg"},
            {"Cruiser & Chopper Mỹ", "cruiser", "/images/harley_fatboy.jpg"},
            {"Cruiser & Touring", "cruiser-touring", "/images/harley_fatboy.jpg"},
            {"Adventure Phượt Bụi", "adventure", "/images/bmw_r1250gs.jpg"},
            {"Tay Ga Độc Lạ Ý", "scooter", "/images/yamaha_tmax560.jpg"},
            {"Pô Độ & Đồ Cào Cào", "gear-parts", "/images/akrapovic_exhaust.jpg"},
            {"Pô Độ & Phụ Tùng Cao Cấp", "phu-tung-po-do", "/images/sc_project_exhaust.jpg"},
            {"Đồ Bảo Hộ & Nón Bảo Hiểm", "do-bao-ho", "/images/agv_helmet.jpg"}
        };

        for (String[] def : catDefs) {
            String name = def[0];
            String slug = def[1];
            String img = def[2];
            Category cat = categoryRepository.findBySlug(slug).orElseGet(() -> 
                categoryRepository.save(Category.builder().name(name).slug(slug).image(img).isDeleted(false).build())
            );
            catMap.put(slug, cat);
        }
        return catMap;
    }

    private Map<Integer, Store> initStores() {
        Map<Integer, Store> storeMap = new HashMap<>();
        User vendor = userRepository.findByEmail("vendor@duytruongmoto.com").orElse(null);
        User admin = userRepository.findByEmail("admin@duytruongmoto.com").orElse(vendor);
        Commission comm = commissionRepository.findAll().stream().findFirst().orElse(null);

        Store s1 = storeRepository.findBySlug("duy-truong-moto-showroom-quan-1").orElseGet(() ->
            storeRepository.save(Store.builder()
                .name("Duy Truong Motor - Flagship Showroom Quận 1")
                .slug("duy-truong-moto-showroom-quan-1")
                .owner(vendor)
                .bio("Showroom trưng bày các dòng siêu môtô đỉnh cao hàng đầu Việt Nam: Ducati, BMW, Kawasaki...")
                .address("Số 88 Đường Nguyễn Hữu Cảnh, Phường 22, Quận 1, TP. Hồ Chí Minh")
                .phone("0903456789")
                .avatar("https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?auto=format&fit=crop&w=300&q=80")
                .cover("https://images.unsplash.com/photo-1558981403-c5f9899a28bc?auto=format&fit=crop&w=1200&q=80")
                .isActive(true).isOpen(true).commission(comm).point(1200L).rating(4.9)
                .eWallet(BigDecimal.valueOf(120000000)).build())
        );
        storeMap.put(1, s1);

        Store s2 = storeRepository.findBySlug("duy-truong-moto-showroom-cau-giay").orElseGet(() ->
            storeRepository.save(Store.builder()
                .name("Duy Truong Motor - Showroom Cầu Giấy Hà Nội")
                .slug("duy-truong-moto-showroom-cau-giay")
                .owner(admin)
                .bio("Chi nhánh miền Bắc chính hãng của hệ thống chuỗi Duy Truong Motor.")
                .address("Số 168 Đường Trần Duy Hưng, Cầu Giấy, Hà Nội")
                .phone("0901234567")
                .avatar("https://images.unsplash.com/photo-1558981403-c5f9899a28bc?auto=format&fit=crop&w=300&q=80")
                .cover("https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?auto=format&fit=crop&w=1200&q=80")
                .isActive(true).isOpen(true).commission(comm).point(980L).rating(5.0)
                .eWallet(BigDecimal.valueOf(85000000)).build())
        );
        storeMap.put(2, s2);

        Store s3 = storeRepository.findBySlug("duy-truong-moto-showroom-da-nang").orElseGet(() ->
            storeRepository.save(Store.builder()
                .name("Duy Truong Motor - Showroom Hải Châu Đà Nẵng")
                .slug("duy-truong-moto-showroom-da-nang")
                .owner(vendor)
                .bio("Chi nhánh miền Trung uy tín chuyên siêu môtô PKL & xe cào cào.")
                .address("Số 234 Đường Nguyễn Văn Linh, Hải Châu, Đà Nẵng")
                .phone("0905678901")
                .avatar("https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?auto=format&fit=crop&w=300&q=80")
                .cover("https://images.unsplash.com/photo-1558981403-c5f9899a28bc?auto=format&fit=crop&w=1200&q=80")
                .isActive(true).isOpen(true).commission(comm).point(850L).rating(4.9)
                .eWallet(BigDecimal.valueOf(60000000)).build())
        );
        storeMap.put(3, s3);

        return storeMap;
    }

    private void seedProduct(Store store, Category category, String name, String slug, String brand,
                             BigDecimal price, BigDecimal promoPrice, int qty, int sold, double rating,
                             String engine, String color, String image, String desc) {
        if (productRepository.findBySlug(slug).isEmpty()) {
            productRepository.save(Product.builder()
                .store(store)
                .category(category)
                .name(name)
                .slug(slug)
                .brand(brand)
                .price(price)
                .promotionalPrice(promoPrice)
                .quantity(qty)
                .sold(sold)
                .rating(rating)
                .engineCapacity(engine)
                .color(color)
                .mainImage(image)
                .description(desc)
                .isActive(true)
                .isSelling(true)
                .build());
        }
    }

    private void initAll60Products(Map<String, Category> catMap, Map<Integer, Store> storeMap) {
"""

# Generate Java code for each product
java_products_code = []
for p in products:
    pid = p['id']
    name = p['name'].replace('\\', '\\\\').replace('"', '\\"')
    slug = p['slug']
    brand = p['brand'].replace('\\', '\\\\').replace('"', '\\"')
    cat_slug = p['category']
    price = p['price']
    promo = p['promotionalPrice']
    qty = p['quantity']
    sold = p['sold']
    rating = p['rating']
    engine = p['engine'].replace('\\', '\\\\').replace('"', '\\"')
    color = p['color'].replace('\\', '\\\\').replace('"', '\\"')
    image = p['image']
    desc = p['description'].replace('\\', '\\\\').replace('"', '\\"').replace('\n', ' ')
    store_id = int(p.get('storeId', 1))
    if store_id not in [1, 2, 3]: store_id = 1

    code_line = f"""        seedProduct(storeMap.get({store_id}), catMap.get("{cat_slug}"),
            "{name}",
            "{slug}",
            "{brand}",
            new BigDecimal("{price}"),
            new BigDecimal("{promo}"),
            {qty}, {sold}, {rating},
            "{engine}",
            "{color}",
            "{image}",
            "{desc}");"""
    java_products_code.append(code_line)

footer = """
    }
}
"""

full_code = header + "\n\n".join(java_products_code) + footer

with open('src/main/java/com/duytruongmoto/ecommerce/data/DataInitializer.java', 'w', encoding='utf-8') as f:
    f.write(full_code)

print("Successfully written complete DataInitializer.java with all 60 products!")
