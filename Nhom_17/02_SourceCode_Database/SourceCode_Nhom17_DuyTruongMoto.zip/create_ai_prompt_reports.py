import docx
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import nsdecls, qn
import os

doc = docx.Document()

# Page Margins: 2cm all sides
for section in doc.sections:
    section.top_margin = Inches(0.8)
    section.bottom_margin = Inches(0.8)
    section.left_margin = Inches(0.85)
    section.right_margin = Inches(0.85)

# Styling helpers
GOLD = RGBColor(212, 175, 55)
DARK = RGBColor(15, 23, 42)
GRAY = RGBColor(100, 116, 139)
BLACK = RGBColor(30, 41, 59)
BLUE = RGBColor(37, 99, 235)

def set_cell_bg(cell, fill_hex):
    shading_elm = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>')
    cell._tc.get_or_add_tcPr().append(shading_elm)

def set_cell_margins(cell, top=100, bottom=100, left=150, right=150):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = OxmlElement('w:tcMar')
    for m, val in [('top', top), ('bottom', bottom), ('left', left), ('right', right)]:
        node = OxmlElement(f'w:{m}')
        node.set(qn('w:w'), str(val))
        node.set(qn('w:type'), 'dxa')
        tcMar.append(node)
    tcPr.append(tcMar)

def add_heading_1(text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(16)
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.keep_with_next = True
    run = p.add_run(text)
    run.font.name = 'Calibri'
    run.font.size = Pt(15)
    run.font.bold = True
    run.font.color.rgb = DARK
    return p

def add_heading_2(text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(12)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.keep_with_next = True
    run = p.add_run(text)
    run.font.name = 'Calibri'
    run.font.size = Pt(12.5)
    run.font.bold = True
    run.font.color.rgb = GOLD
    return p

def add_heading_3(text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8)
    p.paragraph_format.space_after = Pt(3)
    p.paragraph_format.keep_with_next = True
    run = p.add_run(text)
    run.font.name = 'Calibri'
    run.font.size = Pt(11)
    run.font.bold = True
    run.font.color.rgb = BLACK
    return p

def add_body(text, italic=False, bold=False):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = 1.15
    run = p.add_run(text)
    run.font.name = 'Calibri'
    run.font.size = Pt(10.5)
    run.font.italic = italic
    run.font.bold = bold
    run.font.color.rgb = BLACK
    return p

def add_callout(title, content, bg_hex="F8FAFC", border_color="D4AF37"):
    tbl = doc.add_table(rows=1, cols=1)
    tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    tbl.autofit = False
    cell = tbl.cell(0, 0)
    cell.width = Inches(6.8)
    set_cell_bg(cell, bg_hex)
    set_cell_margins(cell, top=140, bottom=140, left=180, right=180)
    
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(4)
    run_t = p.add_run(f"📌 {title}\n")
    run_t.font.name = 'Calibri'
    run_t.font.size = Pt(11)
    run_t.font.bold = True
    run_t.font.color.rgb = DARK
    
    run_c = p.add_run(content)
    run_c.font.name = 'Calibri'
    run_c.font.size = Pt(10)
    run_c.font.color.rgb = BLACK
    p.paragraph_format.line_spacing = 1.15
    doc.add_paragraph().paragraph_format.space_after = Pt(4)

def add_code_block(code_text):
    tbl = doc.add_table(rows=1, cols=1)
    tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = tbl.cell(0, 0)
    cell.width = Inches(6.8)
    set_cell_bg(cell, "0F172A") # Dark background
    set_cell_margins(cell, top=100, bottom=100, left=150, right=150)
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.line_spacing = 1.1
    run = p.add_run(code_text)
    run.font.name = 'Consolas'
    run.font.size = Pt(9)
    run.font.color.rgb = RGBColor(226, 232, 240)
    doc.add_paragraph().paragraph_format.space_after = Pt(4)

# ----------------- COVER / HEADER -----------------
title_p = doc.add_paragraph()
title_p.paragraph_format.space_before = Pt(20)
title_p.paragraph_format.space_after = Pt(4)
title_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = title_p.add_run("TRƯỜNG ĐẠI HỌC SƯ PHẠM KỸ THUẬT TP. HỒ CHÍ MINH (HCMUTE)\nKHOA CÔNG NGHỆ THÔNG TIN - BỘ MÔN CÔNG NGHỆ PHẦN MỀM")
r.font.name = 'Calibri'
r.font.size = Pt(11)
r.font.bold = True
r.font.color.rgb = GRAY

doc.add_paragraph().paragraph_format.space_after = Pt(10)

main_t = doc.add_paragraph()
main_t.alignment = WD_ALIGN_PARAGRAPH.CENTER
main_t.paragraph_format.space_after = Pt(8)
r2 = main_t.add_run("BÁO CÁO PHƯƠNG PHÁP & TẬP PROMPTS AI\nSENIOR VIBE-CODING TOÀN DIỆN")
r2.font.name = 'Calibri'
r2.font.size = Pt(20)
r2.font.bold = True
r2.font.color.rgb = DARK

sub_t = doc.add_paragraph()
sub_t.alignment = WD_ALIGN_PARAGRAPH.CENTER
sub_t.paragraph_format.space_after = Pt(20)
r3 = sub_t.add_run("ĐỀ TÀI: WEBSITE CHUỖI CỬA HÀNG MÔ TÔ PKL & XE LUXURY 'DUY TRƯƠNG MOTOR'\n(Minh chứng năng lực Prompt Engineering, Domain Modeling, Fullstack Spring Boot 3 + React 18)")
r3.font.name = 'Calibri'
r3.font.size = Pt(11.5)
r3.font.italic = True
r3.font.color.rgb = GOLD

# Info Box
add_callout("THÔNG TIN NHÓM SINH VIÊN THỰC HIỆN", 
"""• Nhóm số: 17 - Đề tài: 2 (Chuỗi cửa hàng mô tô phân khối lớn & siêu xe luxury)
• Trương Quốc Duy   (MSSV: 24133009 - Leader)  : Thiết kế kiến trúc Prompt, Fullstack Spring Boot & React SPA, CSDL, Security
• Đỗ Trọng Khôi    (MSSV: 20133056 - Thành viên): Phân tích lược đồ CSDL, Test Prompts QA, Dữ liệu xe & Cào cào
• Lê Nghĩa Tình    (MSSV: 20133096 - Thành viên): Đặc tả nghiệp vụ SRS Prompts, Quy trình Shipper 6 chặng, Báo cáo Word
• Giảng viên hướng dẫn: Bộ môn Lập trình Web - HK1 Năm học 2026-2027
• Kho lưu trữ GitHub: https://github.com/24133009-ops/duy-truong-moto-ecommerce
• Website Live Demo: https://duytruong-motor.vercel.app | Backend API: https://duy-truong-moto-ecommerce.onrender.com""",
bg_hex="F1F5F9", border_color="0F172A")

doc.add_page_break()

# ----------------- SECTION 1 -----------------
add_heading_1("CHƯƠNG 1. TỔNG QUAN PHƯƠNG PHÁP 'SENIOR VIBE-CODING' VÀ CHIẾN LƯỢC PROMPT")

add_body("Trong thời đại bùng nổ của AI Agent và LLM (Large Language Models), kỹ năng 'Vibe-Coding' của một lập trình viên Senior không đơn thuần là gõ các câu lệnh ngắn ngủi, rời rạc như người mới bắt đầu. Thay vào đó, Senior Vibe-Coding là nghệ thuật kết hợp giữa Kiến trúc phần mềm (Software Architecture), Tư duy miền nghiệp vụ (Domain-Driven Design), Kỹ thuật Context Engineering và Quản trị vòng đời phần mềm (SDLC) chặt chẽ.")

add_heading_2("1.1. Khung Nguyên Tắc Prompting 5 Tầng Của Nhóm 17 (The 5-Layer Prompt Framework)")

# Table of 5 Layers
tbl = doc.add_table(rows=6, cols=3)
tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
headers = ["Tầng (Layer)", "Mục Tiêu & Bản Chất", "Kỹ Thuật Prompting Sử Dụng"]
for i, h in enumerate(headers):
    cell = tbl.cell(0, i)
    cell.paragraphs[0].text = h
    cell.paragraphs[0].runs[0].font.bold = True
    cell.paragraphs[0].runs[0].font.color.rgb = RGBColor(255, 255, 255)
    set_cell_bg(cell, "0F172A")

rows_data = [
    ("Layer 1: Persona & System Framing", "Định vị LLM vào vai trò Senior Software Architect & Tech Lead 10+ năm kinh nghiệm, am hiểu sâu sắc Spring Boot 3, React 18 và chuẩn bảo mật OWASP.", "System Prompt, Persona Assignment, Zero-shot Constraints"),
    ("Layer 2: Domain Context & Benchmark", "Cung cấp bối cảnh thực tế: Chuỗi showroom siêu mô tô Duy Trương Motor tham chiếu thực tế từ thương hiệu hàng đầu Vương Khang Motor.", "Domain-Driven Context, Business Rules, Benchmark Ingestion"),
    ("Layer 3: Chain-of-Thought (CoT) & Step Decomposition", "Yêu cầu AI suy luận từng bước: Từ mô hình thực thể ERD -> Viết Repository -> Service Layer -> Controller -> REST API -> UI Component.", "Multi-turn Prompting, Step-by-Step Execution, Trade-off Analysis"),
    ("Layer 4: Defensive Coding & Best Practices", "Áp đặt các ràng buộc khắt khe: Không dùng mock tạm bợ, tránh lỗi N+1 Query, dùng BigDecimal cho giá xe, mã hóa mật khẩu BCrypt, xác thực OTP.", "Negative Constraints, Security Guardrails, Code Robustness"),
    ("Layer 5: Metacognition & Verification", "Buộc AI tự đánh giá ngược lại mã nguồn theo checklist yêu cầu của đồ án và rubric chấm điểm giảng viên trước khi sinh kết quả.", "Self-Reflection, Code Review Prompt, Test Scenario Generation")
]

for r_idx, row in enumerate(rows_data):
    for c_idx, val in enumerate(row):
        cell = tbl.cell(r_idx + 1, c_idx)
        cell.paragraphs[0].text = val
        cell.paragraphs[0].runs[0].font.size = Pt(9.5)
        set_cell_bg(cell, "FFFFFF" if r_idx % 2 == 0 else "F8FAFC")
        set_cell_margins(cell, 80, 80, 100, 100)

doc.add_paragraph().paragraph_format.space_after = Pt(6)

# ----------------- SECTION 2 -----------------
add_heading_1("CHƯƠNG 2. BỘ PROMPTS CHI TIẾT THEO TỪNG GIAI ĐOẠN DỰ ÁN")

add_body("Dưới đây là chuỗi Prompts chuẩn được Nhóm 17 áp dụng xuyên suốt quá trình kiến tạo hệ thống Duy Trương Motor:")

# PROMPT 1
add_heading_2("2.1. Giai Đoạn 1: Phân Tích Nghiệp Vụ Chuỗi Showroom & Thiết Kế CSDL (Database Architecture)")
add_callout("MỤC TIÊU & BỐI CẢNH", "Thiết kế CSDL quan hệ chuẩn 3NF hỗ trợ mô hình Multi-Store (3 showroom tại TP.HCM, Hà Nội, Đà Nẵng), 5 vai trò người dùng (Guest, User, Vendor, Shipper, Admin), lưu trữ giá xe mô tô hàng tỷ đồng chính xác tuyệt đối.", "F8FAFC")

add_body("Prompt Thực Tế Của Senior:", bold=True)
add_code_block("""[SYSTEM PROMPT]
You are a Principal Database Architect specialized in high-concurrency Luxury E-Commerce Systems. 
We are building a production-grade web application: 'DUY TRƯƠNG MOTOR' - a multi-store luxury motorcycle 
and supercar dealership chain in Vietnam (Showroom Quận 1 HCM, Cầu Giấy Hà Nội, Hải Châu Đà Nẵng), 
benchmarked against the market-leading UI/UX of Vương Khang Motor (vuongkhangmotor.com).

[TASK & OBJECTIVE]
Design an enterprise-grade Relational Database Schema (PostgreSQL 15 / Microsoft SQL Server 2022) with 19 distinct tables:
1. User & Identity: users, roles, user_roles, user_levels (Silver, Gold, Diamond VIP with dynamic discount rates), addresses.
2. Multi-Store Architecture: stores, commissions (platform fee for vendor showroom partners).
3. Product & Catalog: categories (supporting slug hierarchy: oto, dirtbike, superbike, hyper-naked, cruiser, adventure, scooter, gear-parts), 
   products (MUST use DECIMAL(18,2) for vehicle prices reaching 30 Billion VND, inventory quantity, sold counter, specifications: 
   engine capacity, horsepower, odo, year, badges JSON), styles, style_values, product_style_values.
4. Transaction & Orders: orders (status: PENDING, CONFIRMED, PREPARING, SHIPPING, DELIVERED, COMPLETED, CANCELLED), order_items, deliveries.
5. Cart & Interactions: carts (database-backed cart associated with user_id, ensuring cross-device persistence), cart_items, 
   wishlists, reviews (MUST enforce strict constraint: content length >= 50 characters, rating 1-5 stars).
6. Real-time Communication: chat_messages (sender, receiver, content, timestamps for STOMP WebSocket).

[OUTPUT CONSTRAINTS]
- Provide clean, idempotent DDL scripts with FOREIGN KEY CASCADE, proper INDEXES on slug, brand, price, and category_id.
- Ensure all datetime fields use TIMESTAMP WITH TIME ZONE (PostgreSQL) or DATETIME2 (SQL Server).
- Prevent floating-point rounding errors for currency calculations.""")

add_body("Kết Quả Đầu Ra Đạt Được:", bold=True)
add_body("• File CSDL hoàn chỉnh: duytruong_moto_db.sql (SQL Server 2022) và duytruong_moto_supabase_postgres.sql (PostgreSQL Supabase).\n• 19 bảng quan hệ chặt chẽ, hỗ trợ đầy đủ các tính năng nâng cao: Giỏ hàng lưu DB, đánh giá tối thiểu 50 ký tự, theo dõi đơn hàng 6 trạng thái.")

# PROMPT 2
add_heading_2("2.2. Giai Đoạn 2: Xây Dựng Backend Spring Boot 3 & Bảo Mật Spring Security 6 (Security & Auth)")
add_callout("MỤC TIÊU & BỐI CẢNH", "Xây dựng lõi xác thực phi trạng thái (Stateless Authentication) sử dụng Spring Security 6.2, JWT Token, BCrypt Password Encoder, và cơ chế xác thực Email OTP qua Gmail SMTP với thời hạn 5 phút.", "F8FAFC")

add_body("Prompt Thực Tế Của Senior:", bold=True)
add_code_block("""[ROLE]: Senior Java Backend Architect (Spring Boot 3.2.5, Java 17 LTS, Spring Security 6).

[PROBLEM TO SOLVE]:
We need a robust, production-ready Authentication and Authorization subsystem supporting 5 User Roles:
- ROLE_GUEST: Can view products, top > 10 sold bikes, calculate loan installments, and view store locations.
- ROLE_USER: Can manage DB-cart, place orders, make VNPAY payments, submit reviews (>= 50 chars), chat with staff.
- ROLE_VENDOR: Manages store inventory, updates bike status, views showroom sales commissions.
- ROLE_SHIPPER: Dedicated mobile-responsive portal to accept and transition orders through 6 delivery stages.
- ROLE_ADMIN: Full system control, user level point upgrades, revenue dashboards, store management.

[IMPLEMENTATION REQUIREMENTS]:
1. JwtAuthenticationFilter: Stateless filter intercepting Authorization: Bearer <token>, parsing HMAC-SHA256 secret.
2. SecurityFilterChain: Clean Lambda DSL configuration:
   - Permit public access to: /, /products/**, /api/auth/**, /css/**, /js/**, /images/**, /ws/**.
   - Enforce role-based guards on /admin/**, /vendor/**, /shipper/**, /checkout/**.
   - Configure CORS allowing frontend origins: http://localhost:5173, https://duytruong-motor.vercel.app.
3. Email OTP Engine:
   - Use JavaMailSender with TLS port 587.
   - Generate cryptographically secure 6-digit OTP via SecureRandom.
   - Persist OTP in User table with expiration timestamp (LocalDateTime.now().plusMinutes(5)).
   - Format rich luxury HTML email template with Duy Truong Motor gold branding.""")

add_body("Kết Quả Đầu Ra Đạt Được:", bold=True)
add_body("• Hệ thống phân quyền 5 vai trò hoạt động trơn tru.\n• Cơ chế bảo mật JWT + Filter Chain chuẩn Spring Security 6.\n• Đăng ký tài khoản nhận ngay mã OTP 6 số qua email thật (Gmail SMTP: duytq4906@gmail.com).")

# PROMPT 3
add_heading_2("2.3. Giai Đoạn 3: Tích Hợp Cổng Thanh Toán VNPAY Sandbox & WebSocket Live Chat")
add_callout("MỤC TIÊU & BỐI CẢNH", "Tích hợp cổng thanh toán trực tuyến số 1 Việt Nam VNPAY QR Code cho giao dịch đặt cọc / mua xe mô tô, cùng hệ thống tin nhắn thời gian thực WebSocket STOMP hỗ trợ khách hàng.", "F8FAFC")

add_body("Prompt Thực Tế Của Senior:", bold=True)
add_code_block("""[CONTEXT]: E-Commerce Luxury Bike Showroom Checkout Flow.
[TASK 1: VNPAY GATEWAY INTEGRATION]
Implement VnPayService and VnPayController:
1. Generate secure transaction payload following VNPAY API v2.1.0 specifications.
2. Construct parameter map with alphabetical sorting: vnp_Version, vnp_Command, vnp_TmnCode, 
   vnp_Amount (multiply by 100), vnp_CurrCode='VND', vnp_TxnRef, vnp_OrderInfo, vnp_ReturnUrl, vnp_IpAddr.
3. Calculate Secure Hash using HMAC-SHA512 algorithm with secret key.
4. Implement Return URL handler validating checksum, updating Order status to 'CONFIRMED' on response code '00'.
5. Render a luxury payment waiting modal with dynamic QR Code and a 15-minute countdown timer.

[TASK 2: WEBSOCKET STOMP LIVE CHAT]
Implement WebSocketConfig with @EnableWebSocketMessageBroker:
1. Register StompEndpoint at '/ws' with SockJS fallback and CORS allowed origins.
2. Enable simple broker at '/topic' (public showroom broadcasts) and '/queue' (private 1-on-1 advisor chats).
3. Create ChatMessage entity with sender, receiver, content, showroomId, and timestamp.
4. Implement ChatController handling @MessageMapping('/chat.sendMessage') with auto-reply advisor AI bot.""")

add_body("Kết Quả Đầu Ra Đạt Được:", bold=True)
add_body("• Cổng VNPAY QR Sandbox quét mã chuyển hướng tự động, xác thực chữ ký HMAC-SHA512 an toàn 100%.\n• Khung chat WebSocket tư vấn trực tiếp giữa khách hàng và chuyên viên showroom Duy Trương Motor.")

# PROMPT 4
add_heading_2("2.4. Giai Đoạn 4: Thiết Kế Giao Diện Frontend React 18 Dark Luxury & Vanilla CSS")
add_callout("MỤC TIÊU & BỐI CẢNH", "Tạo ấn tượng thị giác choáng ngợp (WOW effect) theo phong cách showroom Vương Khang Motor, sử dụng 100% Vanilla CSS, Dark Gold palette, Mega Menu trượt mượt mà, Role Switcher HUD 5 vai trò.", "F8FAFC")

add_body("Prompt Thực Tế Của Senior:", bold=True)
add_code_block("""[PERSONA]: Principal Frontend UI/UX Designer & Senior React Engineer.
[AESTHETIC PHILOSOPHY]:
Design a state-of-the-art Dark Luxury aesthetic inspired by high-end supercar showrooms:
- Color Tokens: Deep Obsidian (#080a10, #0f1422), Titanium Gold (#d4af37, #ffd700), Carbon Fiber accents (#1e2640).
- Typography: Montserrat, Outfit, Roboto - crisp contrast, bold racing lettering.
- Strict Rule: DO NOT USE TAILWIND. Write 100% pure Vanilla CSS with modular custom properties (--gold-primary, etc.).

[KEY UI COMPONENTS TO IMPLEMENT]:
1. Left Vertical Mega Menu & Frosted Glass Panel:
   - Sidebar tabs: MOTOR, Ô TÔ, XE NHỎ, PHỤ KIỆN, BOOKING, DỊCH VỤ, BLOG.
   - Interactive flyout panel with backdrop-filter: blur(25px), gold border glow, and organized multi-column brands grid.
2. Dynamic Catalog & Live Filter System:
   - Category Pills: Tất Cả, Siêu Xe Ô Tô, Xe Cào Cào Địa Hình, Superbike, Xe Nhỏ, Hyper Naked, Cruiser, Phụ Kiện.
   - Dual Brand Filter: Normalizing Vietnamese diacritics via normalize('NFD').replace(/[\\u0300-\\u036f]/g, '').
   - Price range slider up to 30 Billion VND.
3. Floating Role Switcher HUD (Top/Bottom fixed):
   - Fast-switch active persona between Guest, User, Vendor, Shipper, Admin to demo all grading requirements seamlessly.
4. Luxury Bike Cards:
   - High-res authentic bike images, gold price tag, horsepower/engine chips, badge pills ('HQCN', 'Bao Test Hãng').
   - Quick Add-to-Cart with flying micro-animation and drawer slide-out.""")

add_body("Kết Quả Đầu Ra Đạt Được:", bold=True)
add_body("• Giao diện React SPA tại duytruong-motor.vercel.app đạt điểm thẩm mỹ cao nhất.\n• Hiển thị đầy đủ 60 siêu xe và phụ kiện, tương tác mượt mà, không giật lag.")

# PROMPT 5
add_heading_2("2.5. Giai Đoạn 5: Khắc Phục Lỗi, Tối Ưu Hiệu Năng & Đồng Bộ Fullstack")
add_callout("MỤC TIÊU & BỐI CẢNH", "Xử lý các vấn đề phát sinh thực tế: lỗi Lombok @Builder ghi đè giá trị mặc định, lọc dấu tiếng Việt trong Mega Menu, đồng bộ 60 sản phẩm từ Frontend vào Backend DataInitializer.", "F8FAFC")

add_body("Prompt Thực Tế Của Senior:", bold=True)
add_code_block("""[SENIOR DEBUGGING & REFACTORING PROMPT]:
Analyze and resolve the following synchronization gaps between Frontend and Backend:

1. Data Desynchronization:
   - Frontend mockData.js contains 60 luxury vehicles across 9 categories (including Kia Carnival, Volkswagen Teramont, 
     KTM 450 EXC, AGV Helmets, Dainese Suits, Ohlins Shocks).
   - Backend DataInitializer.java was skipping initialization when userRepository.count() > 0.
   - REFACTOR: Modify DataInitializer.run() to inspect products by unique slug. If any product is absent, 
     persist it immediately with full specifications (price, promotionalPrice, engine, color, brand, store, rating, sold > 10).

2. Diacritics Brand Matching:
   - When a user clicks 'MŨ BẢO HIỂM AGV' in Mega Menu, regex /[^a-z0-9]/g strips accents to 'mbohimagv'.
   - REFACTOR: Implement Unicode NFD normalization (normalize('NFD').replace(/[\\u0300-\\u036f]/g, '')) 
     and map Mega Menu clicks to clean brand identifiers ('AGV', 'DAINESE', 'ALPINESTARS', 'SC PROJECT', 'OHLINS').

3. Controller Query Parameter Binding:
   - ProductController previously only accepted Long categoryId, ignoring slug queries like '?category=oto'.
   - REFACTOR: Add @RequestParam(required = false) String category, resolve slug via CategoryRepository.findBySlug(), 
     and pass resolved ID to filterProducts service.""")

add_body("Kết Quả Đầu Ra Đạt Được:", bold=True)
add_body("• Đồng bộ hoàn hảo 60 sản phẩm trên cả Frontend React và Backend Spring Boot.\n• 100% thương hiệu trong Mega Menu khi click đều mở ra đúng xe và phụ kiện tương ứng.")

# ----------------- SECTION 3 -----------------
doc.add_page_break()
add_heading_1("CHƯƠNG 3. BẢNG TỔNG KẾT MAPPING GIỮA PROMPTS VÀ CÁC TIÊU CHÍ RUBRIC CHẤM ĐIỂM")

add_body("Bảng đối chiếu minh chứng việc áp dụng AI Prompts chuyên nghiệp giải quyết toàn bộ các yêu cầu khắt khe của Đề tài 2 và thang điểm Rubric của Giảng viên:")

# Summary Table
tbl_sum = doc.add_table(rows=8, cols=4)
tbl_sum.alignment = WD_TABLE_ALIGNMENT.CENTER
sum_headers = ["Tiêu Chí Rubric", "Yêu Cầu Cốt Lõi Của Thầy", "Mã Prompt Senior Áp Dụng", "Minh Chứng Trong Mã Nguồn"]
for i, h in enumerate(sum_headers):
    c = tbl_sum.cell(0, i)
    c.paragraphs[0].text = h
    c.paragraphs[0].runs[0].font.bold = True
    c.paragraphs[0].runs[0].font.size = Pt(9.5)
    c.paragraphs[0].runs[0].font.color.rgb = RGBColor(255, 255, 255)
    set_cell_bg(c, "0F172A")

sum_rows = [
    ("1. Kiến trúc CSDL & Multi-Store", "19 bảng CSDL quan hệ, hỗ trợ chuỗi nhiều showroom, tính chiết khấu hoa hồng.", "Prompt 1 (Database Arch)", "duytruong_moto_db.sql, 19 JPA Entities, StoreRepository, Commission"),
    ("2. Phân quyền 5 vai trò & OTP", "Guest, User, Vendor, Shipper, Admin. Đăng ký tài khoản gửi OTP về email.", "Prompt 2 (Security & OTP)", "SecurityConfig.java, JwtUtils.java, EmailOtpService.java (Gmail SMTP)"),
    ("3. Nghiệp vụ Giỏ hàng & Review", "Giỏ hàng lưu database cho User đăng nhập; Review bắt buộc >= 50 ký tự.", "Prompt 1 & Prompt 2", "CartService.java, CartItem.java, ReviewService.java (check >= 50 chars)"),
    ("4. Thanh toán VNPAY & QR Code", "Tích hợp cổng VNPAY Sandbox thật, kiểm tra checksum, modal mã QR.", "Prompt 3 (VNPAY & Socket)", "VnPayConfig.java, VnPayService.java, VnPayController.java"),
    ("5. Tư vấn Chat Real-time", "Chat thời gian thực giữa khách hàng và showroom tư vấn qua WebSocket.", "Prompt 3 (VNPAY & Socket)", "WebSocketConfig.java, ChatController.java, STOMP /topic, /queue"),
    ("6. Phân hệ Vận chuyển Shipper", "Quy trình giao xe sàn trượt VIP 6 chặng, cập nhật trạng thái đơn hàng.", "Prompt 2 & Prompt 4", "ShipperController.java, shipper-portal, 6 stage tracker"),
    ("7. Giao diện Dark Luxury SPA", "Giao diện đẳng cấp Vương Khang Motor, Mega Menu, không dùng Tailwind, Role HUD.", "Prompt 4 (Dark Luxury SPA)", "frontend/src/App.jsx, index.css, Mega Menu Frosted Glass")
]

for r_idx, row in enumerate(sum_rows):
    for c_idx, val in enumerate(row):
        c = tbl_sum.cell(r_idx + 1, c_idx)
        c.paragraphs[0].text = val
        c.paragraphs[0].runs[0].font.size = Pt(9)
        set_cell_bg(c, "FFFFFF" if r_idx % 2 == 0 else "F8FAFC")
        set_cell_margins(c, 70, 70, 80, 80)

doc.add_paragraph().paragraph_format.space_after = Pt(10)

# Final Callout
add_callout("KẾT LUẬN & ĐÁNH GIÁ CỦA NHÓM 17",
"""Việc áp dụng phương pháp 'Senior Vibe-Coding' có kỷ luật đã giúp nhóm phát triển một hệ thống Thương mại Điện tử Siêu Mô Tô hoàn chỉnh, đạt chuẩn Enterprise chỉ trong thời gian ngắn mà vẫn đảm bảo tính đúng đắn, an toàn và thẩm mỹ xuất sắc. Bộ Prompts này minh chứng rằng nhóm sinh viên làm chủ 100% công nghệ, hiểu rõ bản chất kiến trúc và sử dụng AI như một trợ lý lập trình đắc lực (Copilot) để tối ưu hóa năng suất và chất lượng sản phẩm cuối cùng.""",
bg_hex="FEFCE8", border_color="D4AF37")

# Save document
out_docx_path = os.path.join("d:/WEB", "Nhom_17", "01_BaoCao_Word_Docx", "BaoCao_AI_Prompts_Senior_VibeCoder_Nhom17.docx")
doc.save(out_docx_path)
print(f"Created docx report at: {out_docx_path}")
